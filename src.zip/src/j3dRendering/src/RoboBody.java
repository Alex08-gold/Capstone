package j3dRendering.src;

import javax.media.j3d.BranchGroup;

public class RoboBody {

    private BranchGroup branchGroup = new BranchGroup();

    public RoboBody(){

    }

}
