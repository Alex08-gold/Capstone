package j3dRendering.src;

public interface Component {
    void render();
}
